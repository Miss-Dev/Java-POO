/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio01_aula11;

/**
 *
 * @author Miss-Dev
 */
public class Teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Chefe chefe = new Chefe(30, 220);
        Horista horista = new Horista(2000, 20);
        Comissionado c = new Comissionado(1000, 10);
        System.out.println("Salário - chefe: "+chefe.calcularSalario()+
                            "\n Salário - horista: "+horista.calcularSalario()+
                            "\n Salário - comissionado: "+c.calcularSalario());
    }
    
}
