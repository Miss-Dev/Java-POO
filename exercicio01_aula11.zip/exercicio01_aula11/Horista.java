/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio01_aula11;

/**
 *
 * @author Miss-Dev
 */
public class Horista extends Funcionario{
    private double valorINSS;
    public Horista(double sb, double valorINSS){
        super(sb);
        this.valorINSS = valorINSS;
    }

    public double getValorINSS() {
        return valorINSS;
    }

    public void setValorINSS(double valorINSS) {
        this.valorINSS = valorINSS;
    }
    
    
    
    @Override
    public double calcularSalario(){
        return this.getSalarioBase()-this.valorINSS;
    }
    
}
