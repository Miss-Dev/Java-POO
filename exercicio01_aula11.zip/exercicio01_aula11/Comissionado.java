/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio01_aula11;

/**
 *
 * @author Miss-Dev
 */
public class Comissionado extends Funcionario{
    
    private double valorDesconto;
    public Comissionado(double sb, double valorDesconto){     
        super(sb);
        this.valorDesconto = valorDesconto;       
    }

    public double getValorDesconto() {
        return valorDesconto;
    }

    public void setValorDesconto(double valorDesconto) {
        this.valorDesconto = valorDesconto;
    }
    

    /**
     *
     * @return
     */
    @Override
    public double calcularSalario(){
        return this.getSalarioBase()-this.valorDesconto;
    }

    
}
