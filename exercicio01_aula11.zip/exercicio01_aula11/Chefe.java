/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio01_aula11;

/**
 *
 * @author Miss-Dev
 */
public class Chefe extends Funcionario{
    private int nHoras;
    public Chefe(double sb, int nHoras){
        super(sb);
        this.nHoras = nHoras;
    }

    public int getnHoras() {
        return nHoras;
    }

    public void setnHoras(int nHoras) {
        this.nHoras = nHoras;
    }
    
    
    @Override
    public double calcularSalario(){
        return this.getSalarioBase()*this.nHoras;
    }
    
}
