/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicio02_aula11;

import java.util.Scanner;



/**
 *
 * @author Miss-Dev
 */
public abstract class Pessoa {
   private String nome;
   private String sexo;
   private int idade;
   
   
    public void lerDados(){
            
        Scanner s = new Scanner(System.in);
        System.out.println("Informe seu nome: ");
        this.setNome(s.nextLine());
        
        do{
            System.out.println("Informe o sexo M ou F: ");
            this.sexo = s.nextLine().toUpperCase();
            
        }while(!verificarSexo(this.sexo));        
        
        System.out.println("Informe sua idade: ");
        this.setIdade(s.nextInt());
        
        
        
    } 
    boolean verificarSexo(String s){
        
        if(s.charAt(0)!= 'F' && s.charAt(0)!='M'){
            System.out.println("Informe F para feminino ou M para masculino");            
            return false;
        }
        return true;
    }
    
   
        
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

   
    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }
   
   
   
   
    
}
