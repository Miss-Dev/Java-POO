/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicio02_aula11;

/**
 *
 * @author Miss-Dev
 */
public class Teste {
     public static void main(String[] args) {
         Adulto a1 = new Adulto();
         Funcionario f1 = new Funcionario();
         
        
         System.out.println("**************dados adulto******************");
         a1.lerDados();
         System.out.println(a1.mostrarDados());
         System.out.println("**************dados funcionario(a)******************");
         f1.lerDados();       
         System.out.println(f1.mostrarDados());
     }
    
}
