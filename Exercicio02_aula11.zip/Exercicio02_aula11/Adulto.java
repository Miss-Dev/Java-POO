/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicio02_aula11;

import java.util.Scanner;

/**
 *
 * @author Miss-Dev
 */
public class Adulto extends Pessoa{
    private String RG, CPF;
  
    
   

    public String getRG() {
        return RG;
    }

    public void setRG(String RG) {
        this.RG = RG;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    
    @Override
    public void lerDados() {
        Scanner s = new Scanner(System.in);
        super.lerDados();       
        System.out.println("Informe o RG: ");
        this.setRG(s.nextLine());
        System.out.println("Informe o CPF: ");
        this.setCPF(s.nextLine());      
        
    }


    public String mostrarDados() {
        return "Nome: "+this.getNome()+"\nSexo: "+this.getSexo()+"\nIdade: "+this.getIdade();
    }
    
    
    
    
}
