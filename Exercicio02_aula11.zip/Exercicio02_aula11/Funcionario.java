/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicio02_aula11;

import java.util.Scanner;

/**
 *
 * @author Miss-Dev
 */
public class Funcionario extends Adulto{
    
    private String cargo, salario;

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getSalario() {
        return salario;
    }

    public void setSalario(String salario) {
        this.salario = salario;
    }
    @Override
    public void lerDados(){
        Scanner s = new Scanner(System.in);
        super.lerDados();
        System.out.println("Informe o cargo: ");
        this.setCargo(s.nextLine());
        System.out.println("Informe o salario: ");
        this.setSalario(s.nextLine());
        
    }
    
    @Override
    public String mostrarDados(){
        return "Nome: "+this.getNome()+"\nCargo: "+this.getCargo()+"\nIdade: "+this.getIdade();
    }
    
    
    
}
