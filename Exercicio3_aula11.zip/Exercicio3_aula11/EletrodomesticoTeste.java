/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicio3_aula11;

/**
 *
 * @author Miss-Dev
 */
public class EletrodomesticoTeste {
    public static void main(String[] args) {
        
        Radio radio = new Radio(110);
        TV tv = new TV(42, 220);
        radio.ligar();
        radio.setSintonia(95.0);
        System.out.println("Rádio sintonizado em: "+radio.getSintonia());
        radio.desligar();
        tv.ligar();
        tv.setVolume(40);
        System.out.println("TV com o volume "+tv.getVolume());
        tv.desligar();
        
        
    }
}
