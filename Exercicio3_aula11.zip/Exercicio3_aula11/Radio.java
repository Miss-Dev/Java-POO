/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicio3_aula11;

/**
 *
 * @author Miss-Dev
 */
public class Radio extends Eletrodomestico {
    
    private double sintonia;
    private int volume;

    public Radio(int voltagem) {
        super(voltagem);
        this.sintonia = 0;
        this.volume = 0;
    }
    
    

    public double getSintonia() {
        return sintonia;
    }

    public void setSintonia(double sintonia) {
        this.sintonia = sintonia;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }
    
    

    @Override
    public void ligar() {
        System.out.println("O rádio foi ligado!");
        this.setLigado(true);

        
    }

    @Override
    public void desligar() {
        System.out.println("O rádio foi desligado!");
        this.setLigado(false);

    }
    
    
}
