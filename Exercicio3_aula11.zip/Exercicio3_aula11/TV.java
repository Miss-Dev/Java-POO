/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercicio3_aula11;

/**
 *
 * @author Miss-Dev
 */
public class TV extends Eletrodomestico{
    
    private int tamanho, canal, volume;

    public TV(int tamanho, int voltagem) {
        super(voltagem);
        this.tamanho = tamanho;
        this.canal = 0;
        this.volume = 0;
    }
    
   
    public int getTamanho() {
        return tamanho;
    }

    public void setTamanho(int tamanho) {
        this.tamanho = tamanho;
    }

    public int getCanal() {
        return canal;
    }

    public void setCanal(int canal) {
        this.canal = canal;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    @Override
    public void ligar() {
        System.out.println("TV Ligada");
        this.setLigado(true);
    }

    @Override
    public void desligar() {
        System.out.println("TV Desligada");
        this.setLigado(false);
       
    }
    
    
    

    
    
    
}
